import React, { Component } from 'react';
import Covid from "./components/covid";

class App extends Component {

  render() {
    return (
         <>
         <Covid />
         </>
    );
  }
}

export default App;